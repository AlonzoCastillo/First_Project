const storyController = require("../controllers/story.controller");

module.exports = (app) => {
  app.post("/api/story", storyController.createNewStory);
  app.get("/api/story", storyController.getAllStories);
  app.get("/api/story/:id", storyController.getOneStory);
  app.put("/api/story/:id", storyController.updateStory);
  app.delete("/api/story/:id", storyController.deleteExistingStory);
};