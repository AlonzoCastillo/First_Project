const Story = require("../models/stories.model");

const createNewStory = (req, res) => {
  Story.create(req.body)
    .then((newStory) => {
      res.json({ newStory });
    })
    .catch((err) => {
      res.status(400).json({ err });
    });
};

const getAllStories= (req, res) => {
  Story.find()
    .then((allStories) => {
      res.json(allStories);
    })
    .catch((err) => {
      res.status(400).json({ err });
    });
};

const getOneStory = (req, res) => {
  Story.findOne({ _id: req.params.id })
    .then((queriedStory) => {
      res.json(queriedStory);
    })
    .catch((err) => {
      res.status(400).json({ err });
    });
};

const updateStory = (req, res) => {
  Story.findOneAndUpdate({ _id: req.params.id }, req.body, {
    new: true,
    runValidators: true,
  })
    .then((updatedStory) => {
      res.json({ updatedStory });
    })
    .catch((err) => {
      res.status(400).json({ err });
    });
};

const deleteExistingStory = (req, res) => {
  Story.deleteOne({ _id: req.params.id })
    .then((deletedResponse) => {
      res.json({ deletedResponse });
    })
    .catch((err) => {
      res.status(400).json({ err });
    });
};

module.exports = { createNewStory, getOneStory, getAllStories, updateStory, deleteExistingStory};