const mongoose = require('mongoose');
const StoriesSchema = new mongoose.Schema ({
    name: {
        type: String,
        required: [
            true,
            "Name is required"
        ],
        minLength: [3, "Name must be at least 3 character"],
    },

    why: {
        type: String,
        required: [
            true,
            "Your WHY is required"
        ],
        minLength: [10, "'Your Why' must be at least 10 character"],
    },

    milestone: {
        type: String,
        required: [
            true,
            "Milestone is required"
        ],
        minLength: [3, "Milestone must be at least 3 character"],
    },

}, { timestamps: true });

const Story = mongoose.model('Story', StoriesSchema)

module.exports = Story;
