import { Link } from "react-router-dom";
import '../static/Dash.css';

const Dashboard = () => {

    return (
        
        <div className="container">

                <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                     <Link to='/home' className="navbar-brand">

                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-yin-yang" viewBox="0 0 16 16">
                                <path d="M9.167 4.5a1.167 1.167 0 1 1-2.334 0 1.167 1.167 0 0 1 2.334 0Z"/>
                                <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0ZM1 8a7 7 0 0 1 7-7 3.5 3.5 0 1 1 0 7 3.5 3.5 0 1 0 0 7 7 7 0 0 1-7-7Zm7 4.667a1.167 1.167 0 1 1 0-2.334 1.167 1.167 0 0 1 0 2.334Z"/>
                            </svg>
                         GymBlog
                    </Link>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item active">
                                    <a class="nav-link" href="/home">Home <span class="sr-only"></span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/add">Add Story</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/view">View All</a>
                                </li>
                            </ul>
                        </div>
                </nav>

                <div className="jumbotron">
                    <h1 className="display-4">Welcome To GymBlog!</h1>

                        <p className="lead">This is where you can share your beginning or be inspired to start your fitness journey!</p>

                        

                    <hr className="my-4"/>

                        <p>Click to add yours below and later view others similar or far different than yours.</p>
                        <p className="lead">
                            <a className="btn btn-primary btn-md" href="/add" role="button">Add your Story</a>
                        </p>
                    </div>

        </div>
      );
    };

export default Dashboard;