import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";


const ViewAll = () => {

    const [allStories, setAllStories] = useState([]);
    useEffect(() => {
      axios
        .get("http://localhost:8000/api/story")
        .then((response) => {
          console.log(response.data);
          setAllStories(response.data);
        })
        .catch((err) => {
          console.log(err.response);
        });
    }, []);

    return (
        <div className="container">

            <nav className="navbar sticky-top navbar-expand-md navbar-dark bg-dark">
                <Link to='/home' className="navbar-brand">

                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-yin-yang" viewBox="0 0 16 16">
                            <path d="M9.167 4.5a1.167 1.167 0 1 1-2.334 0 1.167 1.167 0 0 1 2.334 0Z"/>
                            <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0ZM1 8a7 7 0 0 1 7-7 3.5 3.5 0 1 1 0 7 3.5 3.5 0 1 0 0 7 7 7 0 0 1-7-7Zm7 4.667a1.167 1.167 0 1 1 0-2.334 1.167 1.167 0 0 1 0 2.334Z"/>
                        </svg>
                    GymBlog
                </Link>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav">
                            <li className="nav-item active">
                                <a className="nav-link" href="/home">Home <span className="sr-only"></span></a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="/add">Add Story</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="/view">View All</a>
                            </li>
                        </ul>
                    </div>
            </nav>
        
            {allStories.map((story, index) => {
                return(
                    // <div className="card-group">
                    //     <div key={story._id} className="card">
   
                    //         <div className="card-body">
                    //             <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                    //             <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
                    //             <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
                    //             </svg>
                    //             <h5 className="card-title">{story.name}</h5>
                    //                 <p className="card-text">{story.why}</p>
                    //                 <p className="card-text">{story.milestone}</p>
                    //         </div>
                    //         <div class="card-body">

                    //         <Link to={`/story/${story._id}`}>
                    //             <button className="btn btn-secondary">View</button>
                    //         </Link> 
                            
                    //         <Link to={`/edit/${story._id}`}>
                    //             <button className="btn btn-primary">Update</button>
                    //         </Link>
                            
                    //         </div>
                    //     </div>
                    // </div>

                <div class="row row-cols-1">
                    <div class="col">
                        <div key= {story._id} className="card">

                            <div class="card-body">
                                <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
                                <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
                                </svg>
                                <h5 class="card-title"> {story.name} </h5>
                                    <p class="card-text"> {story.why} </p>
                                    <p className="card-text">{story.milestone}</p>
                            </div>
                            <div class="card-body">

                            <Link to={`/story/${story._id}`}>
                                <button className="btn btn-secondary">View</button>
                            </Link> 
                            
                            <Link to={`/edit/${story._id}`}>
                                <button className="btn btn-primary">Update</button>
                            </Link>
                            
                             </div>
                        </div>
                    </div>
                </div>
                );
            
                })}
        </div>
    );


};

export default ViewAll;