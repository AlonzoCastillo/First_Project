import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const AddStory = () => {
    const [name, setName] = useState("");
    const [why, setWhy] = useState("");
    const [milestone, setMilestone] = useState("");


    const [errors, setErrors] = useState({});
    const navigate = useNavigate();
  
    const handleSubmit = (e) => {
        e.preventDefault();
        axios
        .post("http://localhost:8000/api/story", { name, why, milestone })
        .then((response) => {
            console.log(response);
            navigate("/view");
        })
        .catch((err) => {
            console.log(err.response.data.err.errors);
            setErrors(err.response.data.err.errors);
        });
  };


    return (
        <div class="container">

            <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                <Link to='/home' className="navbar-brand">

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-yin-yang" viewBox="0 0 16 16">
                    <path d="M9.167 4.5a1.167 1.167 0 1 1-2.334 0 1.167 1.167 0 0 1 2.334 0Z"/>
                    <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0ZM1 8a7 7 0 0 1 7-7 3.5 3.5 0 1 1 0 7 3.5 3.5 0 1 0 0 7 7 7 0 0 1-7-7Zm7 4.667a1.167 1.167 0 1 1 0-2.334 1.167 1.167 0 0 1 0 2.334Z"/>
                    </svg>
                         GymBlog
                </Link>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item active">
                                    <a class="nav-link" href="/home">Home <span class="sr-only"></span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/add">Add Story</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/view">View All</a>
                                </li>
                            </ul>
                        </div>
            </nav>

            <form onSubmit={handleSubmit}>

                <h1 class="display-2">Add Story Below</h1>

                <div className="form-group">
                    <label htmlFor="name">Name:</label>
                        <input type="text" class="form-control" placeholder="Full Name" onChange={(e) => setName(e.target.value)} value={name}/>
                        {errors.name ? <p>{errors.name.message}</p> : null}
                </div>

                <div className="form-group">
                    <label htmlFor="why">Why I Started:</label>
                        <input type="text" class="form-control" placeholder="Whats your why?" onChange={(e) => setWhy(e.target.value)} value={why}/>
                        {errors.why ? <p>{errors.why.message}</p> : null}
                </div>

                <div className="form-group">
                    <label htmlFor="milestone">Memorable Milestone:</label>
                        <input type="text" class="form-control" placeholder="What is most Memoorable to you?" onChange={(e) => setMilestone(e.target.value)} value={milestone}/>
                        {errors.milestone ? <p>{errors.milestone.message}</p> : null}
                </div>

                <button className="d-flex flex-row btn btn-primary" type="submit">
                    Add Story
                </button>

            </form>
        
        </div>
    );


};

export default AddStory;