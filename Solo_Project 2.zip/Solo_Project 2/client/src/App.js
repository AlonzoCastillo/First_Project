
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Dashboard from "./components/Dashboard";
import AddStory from './components/AddStory'
import ViewAll from './components/ViewAll';
import StoryFile from './components/StoryFile';
import EditStory from './components/EditStory';

function App() {
  return (
    <div className="App">
      

      <BrowserRouter>
        <Routes>
          <Route path="/home" element={<Dashboard />} />
          <Route path="/add" element={<AddStory />} />
          <Route path="/view" element={<ViewAll />} />
          <Route path="/story/:id" element={< StoryFile />}/>
          <Route path="/edit/:id" element={< EditStory />}/>

        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
